export default function AboutUs() {
  return (
    <div>
      <h1>This is About Us page</h1>
    </div>
  )
}
