

export default function Product() {
  return (
    <div>
      <h1>THis is Product page</h1>
    </div>
  )
}
